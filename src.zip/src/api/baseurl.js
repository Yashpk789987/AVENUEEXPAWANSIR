// export const URL = 'http://54.175.216.120/api';

export const URL = 'http://www.theinternetarmy.com/webcrm/public/api';
